# Backend Skeleton

Structure for a social network backend using modules.
