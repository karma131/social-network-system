export class PostsRepository {}
