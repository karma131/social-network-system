export class PostsController {}
