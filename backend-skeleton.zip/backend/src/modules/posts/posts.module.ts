export class PostsModule {}
