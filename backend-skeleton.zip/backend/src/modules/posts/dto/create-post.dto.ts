export class CreatePostDto {}
