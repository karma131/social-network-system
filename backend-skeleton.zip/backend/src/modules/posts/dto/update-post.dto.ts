export class UpdatePostDto {}
