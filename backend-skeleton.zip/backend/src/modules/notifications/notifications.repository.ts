export class NotificationsRepository {}
